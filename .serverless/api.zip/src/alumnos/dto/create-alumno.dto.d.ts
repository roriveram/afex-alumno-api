export declare class CreateAlumnoDto {
    nombre: string;
    apellido: string;
    edad: number;
    curso: string;
}
