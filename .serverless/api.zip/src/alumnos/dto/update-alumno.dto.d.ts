import { CreateAlumnoDto } from './create-alumno.dto';
declare const UpdateAlumnoDto_base: import("@nestjs/common").Type<Partial<CreateAlumnoDto>>;
export declare class UpdateAlumnoDto extends UpdateAlumnoDto_base {
}
export {};
