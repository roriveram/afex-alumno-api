export declare class Alumno {
    id: string;
    nombre: string;
    apellido: string;
    edad: number;
    curso: string;
}
